# node-dns-spider
找到一个网址在全球所有的ip，并且获取当前位置的ping值

用法：更改这个值就好了，在当前目录执行**node index.js**
```js
var targetUrl = 'www.google.com';
```
效果图

![xiaoguo](/img/GIF.gif)
